import subprocess
import shutil, time


class PDF2TXT:
    def __init__(self, pdf) -> None:
        self.pdf_file = pdf
        self.output_file = 'outputPath'
        
    # Exe who extract the txt with the same format of the pdf file
    def text_extract(self):
        _args = './static/pdftotext.exe -q -layout ' + self.pdf_file 
        subprocess.call( args=_args, shell=False)

        time.sleep(0.01)

        shutil.move('originpath', 'finalPath')

    def clean(self):
        with open(self.output_file, 'r') as file:
            self.text = file.readlines()
            file.close()
        
        # Erase lines with unnesesary text
        # Example
        self.text = [line for line in self.text if ('Page' not in line)]


